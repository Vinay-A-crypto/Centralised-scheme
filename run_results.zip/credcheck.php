<?php
if(!isset($_COOKIE['user_id']))
{
  header("Location:/website/login.html");
}
?>
